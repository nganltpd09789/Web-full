<?php
include_once '../config/config.php';
include_once '../classes/User.php';

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Kiểm tra xem dữ liệu có được gửi đến hay không
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Kiểm tra xem các trường có rỗng không
    if (empty($username) || empty($email) || empty($password)) {
        echo "Vui lòng điền đầy đủ thông tin.";
        exit();
    }

    // Mã hóa mật khẩu
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Đăng ký người dùng
    if ($user->register($username, $email, $hashedPassword)) {
        header("Location: ../views/login.php");
        exit();
    } else {
        echo "Đăng ký thất bại. Vui lòng thử lại.";
    }
} else {
    echo "Yêu cầu không hợp lệ.";
}
?>

<?php
// LoginController.php
session_start();


if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['pass'];

    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['username'] = $user['id'];

        if ($user['role'] == '1') {
            header("Location: ./admin/index.php");
        } else {
            header("Location: ../index.php");
        }
    } else {
        echo "<div id='noti-fail'>Thông tin đăng nhập không chính xác.</div>";
    }
}

if (!isset($_POST['username'])) {
    $_POST['username'] = "";
}
if (!isset($_SESSION['username'])) {
    $_SESSION['username'] = "";
}

?>

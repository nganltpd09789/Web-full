<?php
session_start(); // Đảm bảo khởi động session để sử dụng user_id từ phiên làm việc
include_once '../config/config.php';
include_once '../classes/Cart.php';

$database = new Database();
$db = $database->getConnection();
$cart = new Cart($db);

// Lấy dữ liệu từ form gửi lên
$product_id = $_POST['product_id'];
$quantity = $_POST['quantity'];

// Giả sử bạn đã lưu user_id trong phiên làm việc
$userId = $_SESSION['user_id']; // Lấy user_id từ phiên

// Cập nhật sản phẩm trong giỏ hàng
$cart->updateCartItem($userId, $product_id, $quantity);

// Chuyển hướng về trang giỏ hàng
header("Location: ../views/cart.php");
exit();
?>

<?php
session_start(); // Bắt đầu phiên

include_once '../config/config.php';
include_once '../classes/Order.php';

$database = new Database();
$db = $database->getConnection();
$order = new Order($db);

if (!isset($_SESSION['user_id'])) {
    header("Location: ../views/login.php"); // Chuyển hướng đến trang đăng nhập nếu chưa đăng nhập
    exit();
}

$user_id = $_SESSION['user_id']; // Giả sử người dùng đã đăng nhập

// Thay đổi từ placeOrder sang createOrder
if ($order->createOrder($user_id)) {
    header("Location: ../views/order_success.php"); // Chuyển hướng đến trang thành công
} else {
    echo "Đặt hàng thất bại. Vui lòng thử lại.";
}

exit();
?>

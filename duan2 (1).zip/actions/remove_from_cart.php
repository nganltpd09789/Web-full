<?php
session_start();

// Kiểm tra nếu có id sản phẩm
if (isset($_GET['id']) && isset($_SESSION['cart'][$_GET['id']])) {
    $product_id = $_GET['id'];
    
    // Xóa sản phẩm khỏi giỏ hàng
    unset($_SESSION['cart'][$product_id]);
    
    // Quay lại trang giỏ hàng
    header('Location: ../views/cart.php');
    exit();
}
?>